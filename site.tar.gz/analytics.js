"use strict";
/* ==========================================================================
   analytics.js – gemeinsames Event-Schema (netzwerkweit identisch)
   ==========================================================================
   Es wird noch KEIN echtes Tracking (kein GA4, kein Meta-Pixel, keine ID)
   eingebunden. Diese Datei definiert nur das Vokabular, damit spaeter (nach
   Einbindung einer Consent-Loesung, siehe README) alle vier Portale
   dieselben Event-Namen verwenden.
   ========================================================================== */
(function (root, factory) {
  var mod = factory();
  if (typeof module === "object" && module.exports) { module.exports = mod; }
  if (typeof window !== "undefined") { window.ANALYTICS = mod; }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  var EVENT_SCHEMA = [
    "article_view", "calculator_click", "echtkosten_click", "internal_promo_click",
    "ad_impression", "newsletter_signup", "article_share", "pro_click",
    "object_check_click", "finder_click"
  ];
  return {
    EVENT_SCHEMA: EVENT_SCHEMA,
    /* TODO FUTURE: echte Tracking-ID erst nach Consent-Management-Integration
       eintragen (siehe README, Abschnitt "Cookies/Consent/Datenschutz"). */
    track: function (eventName, payload) {
      if (EVENT_SCHEMA.indexOf(eventName) === -1) { return; }
      if (typeof window !== "undefined" && window.console) {
        // Im MVP nur lokale Konsolen-Ausgabe, kein Netzwerkversand.
        console.debug("[ANALYTICS]", eventName, payload || {});
      }
    }
  };
});
