"use strict";
/* ads.config.js – siehe echtjetzt/ads.config.js fuer ausfuehrliche
   Aktivierungs-Hinweise (identisches Muster, netzwerkweit konsistent). */
(function (root, factory) {
  var mod = factory();
  if (typeof module === "object" && module.exports) { module.exports = mod; }
  if (typeof window !== "undefined") { window.ADS_CONFIG = mod; }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  return {
    enabled: true,
    provider: "adsense",
    /* TODO FUTURE: echte AdSense Publisher-ID eintragen. */
    publisherId: "ca-pub-4819706470693982",
    developmentPlaceholders: false,
    slots: { belowHero: "below_hero", inFeed: "in_feed", inArticle: "in_article", afterArticle: "after_article", sidebar: "sidebar" }
  };
});
