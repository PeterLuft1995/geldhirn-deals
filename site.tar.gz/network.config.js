"use strict";
/* ==========================================================================
   network.config.js – Zentrale Netzwerk-Konfiguration (EchtKosten-Familie)
   ==========================================================================
   Diese Datei ist die EINZIGE Stelle, an der Links zwischen den vier
   Portalen (EchtKosten, EchtJetzt, KaufRadar, LebensRadar) hinterlegt sind.
   Sie wird sowohl im Browser (per <script>-Tag) als auch beim Build
   (per require() in tools/build.js) verwendet - es gibt also nur eine
   einzige Quelle der Wahrheit fuer alle Cross-Links.

   WICHTIG: Enthaelt ausschliesslich oeffentliche URLs, keine Zugangsdaten.

   Domains sind aktuell Platzhalter (siehe README.md, Abschnitt "Domains").
   Beim Kauf der echten Domains hier zentral anpassen - alle Cross-Links
   auf allen Seiten aktualisieren sich dadurch automatisch.
   ========================================================================== */
(function (root, factory) {
  var mod = factory();
  if (typeof module === "object" && module.exports) { module.exports = mod; }
  if (typeof window !== "undefined") { window.NETWORK_CONFIG = mod; }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {

  var config = {
    echtkosten: {
      baseUrl: "https://geldhirn.de",
      name: "Geldhirn Rechner"
    },
    sisterSites: {
      echtjetzt: { baseUrl: "https://news.geldhirn.de", name: "Geldhirn News" },
      kaufradar: { baseUrl: "https://deals.geldhirn.de", name: "Geldhirn Deals" },
      lebensradar: { baseUrl: "https://leben.geldhirn.de", name: "Geldhirn Leben" }
    },

    /* Zentrale Zuordnung: thematischer Schluessel -> Pfad des passenden
       Echtkosten-Rechners. Artikel verlinken NUR ueber diese Schluessel
       (z.B. relatedCalculator: "electricCar"), nie ueber harte URLs.
       Bei neuen Rechnern oder geaenderten Pfaden nur HIER anpassen. */
    CALCULATOR_LINKS: {
      financing:        { path: "/immobilien/baufinanzierung-rechner.html", label: "Baufinanzierungsrechner" },
      property:          { path: "/immobilien/hauskosten-rechner.html", label: "Hauskostenrechner" },
      rentVsBuy:         { path: "/immobilien/mieten-oder-kaufen-rechner.html", label: "Mieten-oder-Kaufen-Rechner" },
      rentalYield:       { path: "/immobilien/mietrendite-rechner.html", label: "Mietrenditerechner" },
      propertyCheck:     { path: "/immobilien/index.html", label: "Immobilien-Sofortcheck" },
      propertyFinder:    { path: "/immobilien/mieten-oder-kaufen-rechner.html", label: "Mieten-oder-Kaufen-Rechner" },
      moving:            { path: "/immobilien/umzugskosten-rechner.html", label: "Umzugskostenrechner" },
      objectCompare:     { path: "/immobilien/objekt-vergleich.html", label: "Objekt-Vergleich" },
      electricCar:       { path: "/energie/eauto-rechner.html", label: "E-Auto-Rechner" },
      carFinancing:      { path: "/energie/autofinanzierung-rechner.html", label: "Auto-Finanzierungsrechner" },
      fuelCost:          { path: "/energie/benzinkosten-rechner.html", label: "Benzinkostenrechner" },
      pv:                { path: "/energie/pv-rechner.html", label: "PV-Rechner" },
      heatPump:          { path: "/energie/waermepumpen-check.html", label: "Waermepumpen-Check" },
      renovation:        { path: "/energie/sanierungskosten-rechner.html", label: "Sanierungskostenrechner" },
      electricity:       { path: "/vertraege/strom-gas.html", label: "Strom- & Gasrechner" },
      insurance:         { path: "/vertraege/versicherungs-check.html", label: "Versicherungs-Check" },
      insuranceCheck:    { path: "/vertraege/versicherungs-check.html", label: "Versicherungs-Check" },
      netIncome:         { path: "/finanzen/brutto-netto-rechner.html", label: "Brutto-Netto-Rechner" },
      savingsPlan:       { path: "/finanzen/sparplan-rechner.html", label: "Sparplanrechner" },
      compoundInterest:  { path: "/finanzen/zinseszins-rechner.html", label: "Zinseszinsrechner" },
      withdrawalPlan:    { path: "/finanzen/entnahmeplan-rechner.html", label: "Entnahmeplanrechner" },
      inflation:         { path: "/finanzen/inflations-rechner.html", label: "Inflationsrechner" },
      pensionGap:        { path: "/finanzen/rentenluecken-rechner.html", label: "Rentenlueckenrechner" },
      creditCompare:     { path: "/finanzen/kredit-vergleich-rechner.html", label: "Kreditvergleichsrechner" },
      feasibility:       { path: "/finanzen/machbarkeitsrechner.html", label: "Machbarkeitsrechner" },
      vat:               { path: "/finanzen/umsatzsteuer-rechner.html", label: "Umsatzsteuerrechner" },
      overallPlan:       { path: "/finanzen/gesamtplan.html", label: "Gesamtplanrechner" },
      /* TODO FUTURE: eigener Echtkosten-Tierkostenrechner - sobald live, hier eintragen. */
      petCost: null
    }
  };

  /* Liefert die vollstaendige URL zu einem Echtkosten-Rechner anhand des
     Schluessels. Existiert der Rechner (noch) nicht, wird auf die
     Echtkosten-Startseite verwiesen statt eine kaputte URL zu erzeugen. */
  config.calculatorUrl = function (key) {
    var entry = this.CALCULATOR_LINKS[key];
    if (!entry || !entry.path) { return this.echtkosten.baseUrl + "/index.html"; }
    return this.echtkosten.baseUrl + entry.path;
  };

  config.calculatorLabel = function (key) {
    var entry = this.CALCULATOR_LINKS[key];
    return entry ? entry.label : "Echtkosten-Rechner";
  };

  return config;
});
