"use strict";
/* site.config.js – KaufRadar: Struktur der Website (nur fuer node tools/build.js). */
module.exports = {
  siteType: "buying-guide",
  hasBreakingBar: false,
  nav: [
    { label: "Rechner", external: "https://geldhirn.de" },
    { label: "Haus", category: "haus" },
    { label: "Energie", category: "energie" },
    { label: "Technik", category: "technik" },
    { label: "Auto", category: "auto" },
    { label: "Shopping", category: "shopping" },
    { label: "Deals", category: "deals" },
    { label: "Vergleiche", category: "vergleiche" },
    { label: "Ratgeber", category: "ratgeber" },
    { label: "Rechner", external: "https://www.echtkosten.de/" }
  ],
  categories: [
    { id: "haus", slug: "haus", label: "Haus & Wohnen", description: "Renovierung, Sanierung, Garten und Pool – was sich wirklich lohnt.", icon: "house" },
    { id: "energie", slug: "energie", label: "Energie", description: "Photovoltaik, Speicher, Waermepumpe und Energiesparen im Vergleich.", icon: "bolt" },
    { id: "technik", slug: "technik", label: "Technik", description: "Smartphones, Computer, Fernseher, KI-Produkte und Haushaltsgeraete.", icon: "chip" },
    { id: "auto", slug: "auto", label: "Auto", description: "Autos, E-Autos, Gebrauchtwagen, Leasing, Wallboxen und E-Bikes.", icon: "car" },
    { id: "shopping", slug: "shopping", label: "Shopping", description: "Angebote, Deals und Preisvergleiche eingeordnet.", icon: "bag" },
    { id: "deals", slug: "deals", label: "Deals", description: "Aktuell relevante Angebote im Kostencheck.", icon: "tag" },
    { id: "vergleiche", slug: "vergleiche", label: "Vergleiche", description: "Produkt- und Kostenvergleiche im Detail.", icon: "scale" },
    { id: "ratgeber", slug: "ratgeber", label: "Ratgeber", description: "Kaufberatung zum Nachlesen – verstaendlich erklaert.", icon: "book" }
  ],
  /* Reihenfolge auf ausdrücklichen Wunsch festgelegt: Haus zuerst (wie bisher),
     danach Auto, danach Deals, danach der Rest. */
  homepageSections: [
    { id: "haus-wohnen", title: "Haus & Wohnen", categories: ["haus"], max: 4 },
    { id: "auto-mobilitaet", title: "Auto & E-Mobilitaet", categories: ["auto"], max: 3 },
    { id: "deals", title: "Deals", categories: ["deals"], max: 3 },
    { id: "energie-sparen", title: "Energie sparen", categories: ["energie"], max: 3 },
    { id: "technik", title: "Technik", categories: ["technik"], max: 3 },
    { id: "vergleiche", title: "Unsere Vergleiche", categories: ["vergleiche"], max: 3 },
    { id: "shopping", title: "Shopping", categories: ["shopping"], max: 3 },
    { id: "ratgeber", title: "Beliebte Ratgeber", categories: ["ratgeber"], max: 3 },
    { id: "lohnt-sich", title: "Was lohnt sich wirklich?", categories: null, max: 3, mode: "trending" },
    { id: "neueste", title: "Aktuelle Kauf-News", categories: null, max: 8, mode: "newest" }
  ]
};
