"use strict";
/* brand.config.js – zentrale Markenkonfiguration KaufRadar.
   Einzige Stelle fuer Markenname/Claim/Farbe. Aendern + `node tools/build.js`
   genuegt, um die ganze Seite umzubenennen. */
(function (root, factory) {
  var mod = factory();
  if (typeof module === "object" && module.exports) { module.exports = mod; }
  if (typeof window !== "undefined") { window.BRAND_CONFIG = mod; }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  return {
    siteId: "kaufradar",
    name: "Geldhirn Deals",
    claim: "Lohnt sich das wirklich?",
    tagline: "Kaufberatung fuer Haus, Energie, Technik und Auto – mit echten Kosten statt Werbeversprechen.",
    domain: "https://deals.geldhirn.de",
    themeColor: "#0A76A0",
    backgroundColor: "#F5F8FA",
    newsletterHeadline: "Die besten Deals, Vergleiche und Spartipps.",
    newsletterSub: "Einmal woechentlich die relevantesten Kaufberatungen – kostenlos, jederzeit abbestellbar.",
    footerNote: "Geldhirn Deals ist ein Angebot von Geldhirn – kostenlose Rechner, Ratgeber und Nachrichten rund ums Geld.",
    social: { shareText: "Gelesen auf Geldhirn Deals:" }
  };
});
